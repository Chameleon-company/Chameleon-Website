import React, { Component } from 'react';
import About from '../../components/about/About';

const AboutUS = () => {
  return <About />;
};

export default AboutUS;
