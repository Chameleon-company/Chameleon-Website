import { Container, Row, Col } from 'react-bootstrap';
import React, { Component } from 'react';

class Contact extends Component {
  render() {
    return (
    
        <Container>
        <Row>
          <h1>Contact</h1>
          <Col xs={12}>
            <div>
             
            </div>
          </Col>
        </Row>
      </Container>
    );
  }
}

export default Contact;